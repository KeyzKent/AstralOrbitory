# ASTRAL SPECTRUM — 3.5D Levitating City + Operations Console

## Open it
Open **Astral_Spectrum_3_5D_City_Operations.html** in a current browser (Chrome, Firefox, Edge or Safari). This is a single-file, self-contained HTML application; no external JavaScript, asset server or login is required.

WebGL renders the live 3D city when available. If your browser/device disables WebGL, the application shows the included **3.5D concept image** instead; flight routes and edits will not be visibly reflected in the static fallback. The UI for encoding, repairs, exports and design control can still be used.

## City and reference-inspired architectural systems
- 25 editable architectural modules: Gothic cathedrals and spires, sculpted arrow brutalist structures, stacked neon towers, skybridges, orbital research, plasma/refinery hubs, biosphere, spaceports, fortress, sculptural plaza, hydro-atrium, motor bays.
- Tiered levitating district plate, circular/radial aerospace transit rings, portals, landing pads, central comms tower, illuminated Gothic bridge arches, hover and repair zones.
- 12 animated solar-flux-inspired rotor assemblies, up to 24 autonomous flying spacecraft, active repair drones, flight corridors and minimap.
- Six guided districts, auto tour, free camera, click-to-select module editor.
- Save/load city JSON; export module, spacecraft, motor or entire city as STL.

## Flight and architecture controls
- **W A S D**: pilot camera horizontally
- **Q / E**: descend/ascend
- **Shift**: speed boost
- **Drag**: look around; mouse wheel: move forward/back
- Click a structure to edit architecture type, material palette, scale, height, rotation or location.
- **ADVANCE DISTRICT** steps through six scenes; **AUTO TOUR** automatically cycles them.
- Footer **CONCEPT VIEW** toggles a visual reference rendering. Footer **FLUX LAB**, **NETWORK I/O**, **REPAIR OPS** jump directly to the relevant scroll panel.

## Internet encoding / data I/O
- Operator-entered INPUT and read-only OUTPUT with **Base64 UTF-8**, **hexadecimal**, **binary bytes**, **URI percent encoding**, and **JSON validation/pretty-print**.
- Encode/decode dropdown; translate, reverse I/O, clear, copy output, export an I/O event log and produce structured repair packet JSON.
- **TRANSMIT** uses a clearly labeled local loopback if no live endpoint has been connected. This is NOT transmission over the internet.
- Optional **ws:// or wss:// WebSocket** connection may be entered and initiated by the operator. The package does not include a remote server. Any received payload is shown as input and logged, never interpreted/executed as an instruction.

## Flux and solar-piezo systems
- Dropdowns for hybrid, photovoltaic, piezo recovery, driven magnetic motor, plasma research visualization, or motor isolation.
- Field direction: inverted, outverted, oscillating or steady. Control bus: city, dock, fleet, transportation or building.
- User-adjustable request, apply, pulse test, stabilize and shunt/stop. Motor animation follows configured mode and field direction.
- All power, RPM and levitation indications are **illustrative simulation values**, not scientific performance claims or physical hardware telemetry. Magnetic repulsion does not create unlimited energy, and piezoelectricity requires externally provided mechanical input.

## Repair order monitoring
- Create orders for **Electronics, Spacecraft, Transportation, Buildings**.
- Choose a system/target, failure category, priority and dispatch team.
- Order state machine: QUEUED → DIAGNOSING → REPAIRING → COMPLETE; optionally cancel.
- Manual control or automatic progress option; simulated repair drones appear near active targets.
- Filter open/active/closed orders, persist locally where localStorage is available, export orders as JSON, and clear closed work.
- These are demonstration repair workflows only. No actual motors, vehicles, buildings, servers or equipment are remotely controlled.

## STL exports
Directory `STL_Models/` contains **31 binary STL files**: whole static city, platform, 25 module types/instances, three craft and one motor assembly. STL represents static surfaces and does not carry movement, materials, WebGL shaders or interface controls. The CAD meshes are conceptual overlapping visual meshes, not watertight, engineer-reviewed, or ready to manufacture without repair.

## Rebuilding
The folder `Source/` contains the geometry generator (`geometry-core.js`), UI template, operations controls, assembly script and STL exporter. Node.js can regenerate models using `node export-stl.js`; Python 3 can rebuild the HTML from the extracted `Source/` folder using `python assemble.py` (the preview JPG is read from the parent folder). The ready-to-run bundled HTML is the primary artifact.

## Design status
A software visualization intended for worldbuilding and a game/software prototyping workflow. Hyperspace, anti-gravity, atmospheric megacity levitation and plasma-core propulsion are speculative designs, not demonstrated engineering systems.
