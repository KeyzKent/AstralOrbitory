/** Export static STL assets from the precise geometry used by the browser renderer.
 * The city and craft are conceptual and animated systems do not carry animation in STL. */
const fs=require('fs'),path=require('path');
const G=require('./geometry-core.js');const bundled=path.join(__dirname,'..','STL_Models');const out=fs.existsSync(bundled)?bundled:path.join(__dirname,'exports');fs.mkdirSync(out,{recursive:true});
function save(name,g){const data=Buffer.from(g.toSTL(name));const p=path.join(out,name+'.stl');fs.writeFileSync(p,data);console.log(name,g.triangles,'triangles',Math.round(data.length/1024)+' KiB');}
const models=G.defaultModules();
save('ASTRAL_3_5D_Platform_and_Docking_Geometry',G.cityPlatform());
save('ASTRAL_3_5D_Complete_Levitating_City',G.completeCity(models,14));
for(let model of models)save('District_Module_'+String(model.id).padStart(2,'0')+'_'+model.type,G.building(model));
for(let [kind,file] of [['cruiser','X1_Orbital_Refinery_Cruiser'],['scout','Hyperspace_Interceptor_Scout'],['freighter','Mineral_Harvesting_Freighter']])save(file,G.ship(kind));
let motor=G.motorBase();G.appendGeo(motor,G.motorRotor());save('Flux_Solar_Piezo_Motor_Exploded_Concept',motor);
