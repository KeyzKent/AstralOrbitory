/* ASTRAL SPECTRUM — dependency-free procedural geometry, shared by browser and STL builder.
 * Units are conceptual metres; levitation, hyperspace, and plasma cores are speculative art features. */
(function(root){
'use strict';
const TAU=Math.PI*2, DEG=Math.PI/180;
const PALETTES={
  onyx:{metal:'#252d3e',face:'#39465a',edge:'#798ca7',light:'#a56bff',hot:'#ff365f',glass:'#1b3d63'},
  gunmetal:{metal:'#333c45',face:'#576271',edge:'#bac6d3',light:'#49ceff',hot:'#ff5268',glass:'#26465c'},
  obsidian:{metal:'#161b27',face:'#343044',edge:'#80799a',light:'#d29aff',hot:'#ff5578',glass:'#252547'},
  titanium:{metal:'#4b5562',face:'#697787',edge:'#cad8e4',light:'#73baff',hot:'#ff665e',glass:'#365573'},
  crimson:{metal:'#211e2d',face:'#4c283e',edge:'#926b8a',light:'#dd78ff',hot:'#ff3449',glass:'#522547'}
};
function hex(h){let x=h.replace('#',''); return [parseInt(x.slice(0,2),16)/255,parseInt(x.slice(2,4),16)/255,parseInt(x.slice(4,6),16)/255];}
function I(){return [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];}
function mult(a,b){let r=new Array(16);for(let c=0;c<4;c++)for(let z=0;z<4;z++){r[c*4+z]=0;for(let k=0;k<4;k++)r[c*4+z]+=a[k*4+z]*b[c*4+k];}return r;}
function tr(x,y,z){let a=I();a[12]=x;a[13]=y;a[14]=z;return a;}
function sc(x,y,z){let a=I();a[0]=x;a[5]=y;a[10]=z;return a;}
function ry(t){let c=Math.cos(t),s=Math.sin(t);return [c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1];}
function rx(t){let c=Math.cos(t),s=Math.sin(t);return [1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1];}
function pt(m,p){return [m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]];}
class Geo{
 constructor(){this.data=[];this.triangles=0;this.m=I();this.stack=[];this._color={};}
 push(x=0,y=0,z=0,angle=0,sx=1,sy=1,sz=1){this.stack.push(this.m);this.m=mult(this.m,mult(tr(x,y,z),mult(ry(angle),sc(sx,sy,sz))));return this;}
 pop(){this.m=this.stack.pop()||I();return this;}
 tri(p,q,r,col='#495263',glow=0){let a=pt(this.m,p),b=pt(this.m,q),c=pt(this.m,r), u=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],v=[c[0]-a[0],c[1]-a[1],c[2]-a[2]]; let n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];let L=Math.hypot(...n)||1; n=n.map(x=>x/L);let color=this._color[col]||(this._color[col]=hex(col));for(let p0 of [a,b,c])this.data.push(...p0,...n,...color,glow);this.triangles++;return this;}
 quad(a,b,c,d,col,glow=0){this.tri(a,b,c,col,glow);this.tri(a,c,d,col,glow);return this;}
 box(x,y,z,w,h,d,col='#454f60',glow=0){let a=x-w/2,b=x+w/2,c=y-h/2,e=y+h/2,f=z-d/2,g=z+d/2;this.quad([a,c,g],[b,c,g],[b,e,g],[a,e,g],col,glow);this.quad([b,c,f],[a,c,f],[a,e,f],[b,e,f],col,glow);this.quad([a,c,f],[a,c,g],[a,e,g],[a,e,f],col,glow);this.quad([b,c,g],[b,c,f],[b,e,f],[b,e,g],col,glow);this.quad([a,e,g],[b,e,g],[b,e,f],[a,e,f],col,glow);this.quad([a,c,f],[b,c,f],[b,c,g],[a,c,g],col,glow);return this;}
 cylinder(x,y,z,r0,r1,h,col='#454f60',segments=16,glow=0){let base=y-h/2,top=y+h/2;for(let j=0;j<segments;j++){let a=TAU*j/segments,b=TAU*(j+1)/segments;let p=[x+r0*Math.cos(a),base,z+r0*Math.sin(a)],q=[x+r0*Math.cos(b),base,z+r0*Math.sin(b)],r=[x+r1*Math.cos(b),top,z+r1*Math.sin(b)],s=[x+r1*Math.cos(a),top,z+r1*Math.sin(a)];this.quad(p,q,r,s,col,glow);if(r0>0)this.tri([x,base,z],q,p,col,glow);if(r1>0)this.tri([x,top,z],s,r,col,glow);}return this;}
 torus(x,y,z,R,tube,col='#6d7891',segments=40,sides=7,glow=0){for(let i=0;i<segments;i++)for(let j=0;j<sides;j++){const f=(a,b)=>{let u=TAU*a/segments,v=TAU*b/sides;return [x+(R+tube*Math.cos(v))*Math.cos(u),y+tube*Math.sin(v),z+(R+tube*Math.cos(v))*Math.sin(u)]};this.quad(f(i,j),f(i+1,j),f(i+1,j+1),f(i,j+1),col,glow);}return this;}
 sphere(x,y,z,r,col='#45536b',seg=14,lat=8,glow=0){for(let i=0;i<seg;i++)for(let j=0;j<lat;j++){const f=(a,b)=>{let u=TAU*a/seg,v=Math.PI*b/lat;return [x+r*Math.sin(v)*Math.cos(u),y+r*Math.cos(v),z+r*Math.sin(v)*Math.sin(u)];};this.quad(f(i,j),f(i+1,j),f(i+1,j+1),f(i,j+1),col,glow);}return this;}
 beam(a,b,r,col='#7c8ca2',glow=0,segments=7){let v=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],len=Math.hypot(...v)||1,uz=v.map(x=>x/len),ref=Math.abs(uz[1])>.9?[1,0,0]:[0,1,0],u=[ref[1]*uz[2]-ref[2]*uz[1],ref[2]*uz[0]-ref[0]*uz[2],ref[0]*uz[1]-ref[1]*uz[0]];let ul=Math.hypot(...u);u=u.map(x=>x/ul);let w=[uz[1]*u[2]-uz[2]*u[1],uz[2]*u[0]-uz[0]*u[2],uz[0]*u[1]-uz[1]*u[0]];function ring(p,t){return [p[0]+r*(Math.cos(t)*u[0]+Math.sin(t)*w[0]),p[1]+r*(Math.cos(t)*u[1]+Math.sin(t)*w[1]),p[2]+r*(Math.cos(t)*u[2]+Math.sin(t)*w[2])];}for(let i=0;i<segments;i++){let t=TAU*i/segments,vv=TAU*(i+1)/segments;this.quad(ring(a,t),ring(a,vv),ring(b,vv),ring(b,t),col,glow);}return this;}
 toSTL(name='Astral Spectrum'){let n=this.triangles, buf=new ArrayBuffer(84+n*50),d=new DataView(buf);let te=new TextEncoder();let namebytes=te.encode(name.slice(0,80));for(let i=0;i<namebytes.length;i++)d.setUint8(i,namebytes[i]);d.setUint32(80,n,true);let o=84;for(let k=0;k<this.data.length;k+=30){for(let j=3;j<6;j++)d.setFloat32(o+(j-3)*4,this.data[k+j],true);o+=12;for(let vert=0;vert<3;vert++)for(let c=0;c<3;c++)d.setFloat32(o+(vert*3+c)*4,this.data[k+vert*10+c],true);o+=36;d.setUint16(o,0,true);o+=2;}return buf;}
}
function cityPlatform(){let g=new Geo(),P=PALETTES.onyx;
 // Massive multi-layer floating deck, dark tapered foundation, luminous inner levitation toroids.
 g.cylinder(0,-13,0,106,151,30,P.metal,72);g.cylinder(0,4.8,0,153,150,8,P.face,72);g.cylinder(0,9.3,0,150,150,1.5,P.metal,72);
 for(let y of [-24,-13,-3,5,10.2])g.torus(0,y,0,151-(y<0?(-y)*1.26:0),1.05,y===10.2?P.light:P.edge,72,6,y===10.2?0.5:0.12);
 g.torus(0,-20,0,58,4.5,P.light,52,9,0.9);g.torus(0,-30,0,34,3,P.hot,46,8,0.92);g.cylinder(0,-29,0,27,43,14,P.metal,40);g.sphere(0,-42,0,12,P.light,20,10,0.85);
 for(let i=0;i<12;i++){let a=i*TAU/12,x=Math.cos(a),z=Math.sin(a);g.push(x*104,-17,z*104,a+Math.PI/2);g.cylinder(0,-8,0,6,8,16,P.face,12);g.torus(0,-18,0,7,1.5,P.light,18,6,0.7);g.cylinder(0,-25,0,4,7,18,P.metal,10);g.pop();}
 for(let r of [32,78,117,140])g.torus(0,10.5,0,r,r===117?1.05:0.55,r===117?P.light:P.edge,84,5,r===117?0.9:0.27);
 // Six elevated docking gates and symmetrical spoke roads; rails and landing target markings.
 for(let i=0;i<6;i++){let a=i*TAU/6;g.push(0,0,0,a);g.box(0,12,118,13,2,68,P.face);g.box(-6.2,13.1,116,0.62,1,71,P.light,.65);g.box(6.2,13.1,116,0.62,1,71,P.light,.65);g.cylinder(0,10,150,17,17,2,P.metal,24);g.torus(0,12,150,14,1.1,P.hot,32,6,.9);g.box(0,12.1,150,13,0.3,1,P.edge,.7);g.box(0,12.1,150,1,0.3,13,P.edge,.7);
 for(let j=0;j<5;j++){g.box(-4,12.6,95+j*14,1.2,.25,3.5,P.light,.48);g.box(4,12.6,95+j*14,1.2,.25,3.5,P.light,.48);}
 g.pop();}
 // radial passageways / deck sector geometry
 for(let i=0;i<12;i++){let a=i*TAU/12;g.push(0,0,0,a);g.box(0,10.7,71,2,0.3,72,P.edge,.4);g.box(0,11,69,.35,.2,55,P.light,.5);g.pop();}
 // Central gateway tower ring and orbital power corona.
 g.cylinder(0,14,0,25,22,9,P.face,40);g.torus(0,19,0,23,2.1,P.hot,52,7,.85);g.cylinder(0,16,0,12,9,16,P.metal,24);g.torus(0,27,0,12,2.2,P.light,36,7,.9);
 // subsidiary floating petals
 for(let a=0;a<6;a++){let t=a*TAU/6+TAU/12;xpetal(g,t,P);}return g;
}
function xpetal(g,a,P){g.push(Math.cos(a)*196,-12,Math.sin(a)*196,-a);g.cylinder(0,1,0,20,29,8,P.metal,28);g.cylinder(0,6,0,29,29,2,P.face,28);g.torus(0,7.2,0,25,1.7,P.light,32,6,.6);g.torus(0,-7,0,17,1.4,P.hot,24,6,.7);g.pop();}
function windows(g,xmin,zmin,w,h,d,P,rows=5,cols=2){for(let i=0;i<rows;i++){let y=7+i*(h-14)/Math.max(1,rows-1);for(let j=0;j<cols;j++){let xx=(j-(cols-1)/2)*(w/Math.max(1,cols))*0.8;g.box(xx,y,zmin+d/2+.08,1.2,3.3,.26,P.light,.62);g.box(xx,y,zmin-d/2-.08,1.2,3.3,.26,P.light,.62);}}}
function building(spec){let g=new Geo(),P=PALETTES[spec.palette]||PALETTES.onyx;let t=spec.type;g.push(spec.x,11,spec.z,spec.rotation||0,spec.scale||1,(spec.scale||1)*(spec.height||1),spec.scale||1);
 if(t==='gothic'){
   g.box(0,18,0,23,36,19,P.metal);g.box(0,41,0,18,22,14,P.face);g.cylinder(0,63,0,9,4,31,P.face,8);g.cylinder(0,88,0,4.3,0,28,P.metal,8);
   for(let s of [-1,1]){g.box(s*11,20,0,4,38,23,P.face);g.cylinder(s*10.5,52,0,3.4,0,30,P.metal,8);g.beam([s*12,4,10],[s*17,35,10],2,P.edge);g.beam([s*12,4,-10],[s*17,35,-10],2,P.edge);}
   for(let s of [-1,1])for(let j=0;j<5;j++){g.box(s*7,8+j*11,9.57,2.4,7,.5,P.light,.72);g.box(s*7,8+j*11,-9.57,2.4,7,.5,P.light,.72);}
   g.torus(0,40,0,17,1.15,P.hot,24,5,.58);
 }else if(t==='arrow'){
   g.cylinder(0,11,0,16,11,22,P.face,8);g.cylinder(0,33,0,11,10.5,36,P.metal,8);g.cylinder(0,62,0,10.5,14,22,P.face,8);g.cylinder(0,78,0,14,0,28,P.metal,8);
   for(let d=0;d<4;d++){let a=d*TAU/4;g.push(0,0,0,a);g.box(0,23,12,6,39,4,P.metal);g.beam([0,3,15],[0,44,20],2.1,P.edge);g.box(0,53,12,1.2,38,.8,P.light,.72);g.pop();}g.torus(0,24,0,18,1.3,P.hot,32,6,.55);
 }else if(t==='neon'){
   g.box(0,24,0,21,48,19,P.metal);for(let i=0;i<4;i++){let y=14+i*16,phase=i%2?Math.PI/2:0;g.push(0,0,0,phase);g.box(0,y,0,31,11,26,P.glass);g.box(0,y+6.2,0,34,.8,29,P.face);g.box(0,y-5.8,0,32,.8,27,P.face);for(let side of [-1,1]){g.box(side*15.7,y,0,.6,11,19,P.light,.56);g.box(0,y,side*13.3,26,11,.6,P.light,.38);}g.pop();}g.cylinder(0,73,0,8,4,20,P.face,16);g.cylinder(0,91,0,4,0,18,P.metal,16);g.sphere(0,99,0,2,P.light,12,7,.9);
 }else if(t==='orbital'){
   g.cylinder(0,14,0,23,19,27,P.metal,32);g.torus(0,22,0,27,3.6,P.face,48,8);g.torus(0,22,0,28.4,.8,P.light,48,6,.85);g.cylinder(0,36,0,13,8,25,P.face,24);g.sphere(0,57,0,9,P.glass,20,9,.4);g.torus(0,57,0,11,1.5,P.hot,28,7,.84);
   for(let i=0;i<6;i++){let a=TAU*i/6;g.push(0,0,0,a);g.box(0,12,23,8,8,15,P.face);g.box(0,16.4,23,9,.5,16,P.light,.65);g.pop();}
 }else if(t==='refinery'){
   g.cylinder(0,9,0,22,19,18,P.metal,24);g.torus(0,19,0,23,2,P.hot,36,6,.84);g.sphere(0,30,0,13,P.glass,20,10,.45);g.torus(0,29,0,14,2.1,P.light,36,8,.9);g.cylinder(0,39,0,8,0,16,P.face,16);
   for(let i=0;i<6;i++){let a=TAU*i/6,x=19*Math.cos(a),z=19*Math.sin(a);g.cylinder(x,22,z,4.4,3.5,35,P.face,10);g.torus(x,30,z,4.4,.85,P.hot,13,6,.75);g.beam([x,5,z],[x,43,z],1.3,P.edge);}
 }else if(t==='bio'){
   g.cylinder(0,8,0,23,23,16,P.metal,28);g.sphere(0,24,0,24,P.glass,28,16,.15);g.cylinder(0,21,0,20,0,28,P.face,28);g.torus(0,16,0,22,1.5,P.light,36,6,.75);g.torus(0,27,0,15,1.05,P.light,36,6,.6);g.cylinder(0,51,0,3,0,24,P.metal,10);
   for(let a=0;a<8;a++){let angle=a*TAU/8;g.beam([23*Math.cos(angle),16,23*Math.sin(angle)],[0,47,0],.6,P.edge);}
 }else if(t==='fortress'){
   g.box(0,14,0,33,28,31,P.metal);g.box(0,32,0,29,13,28,P.face);g.box(0,44,0,22,13,22,P.metal);g.cylinder(0,62,0,13,0,35,P.face,8);
   for(let a=0;a<4;a++){g.push(0,0,0,a*TAU/4);g.box(0,27,15,26,5,4,P.edge);g.box(0,9,15,22,7,2,P.glass);for(let i=0;i<5;i++)g.box(-10+i*5,12,16.3,2,4,.4,P.light,.7);g.pop();}
   for(let x of [-16,16])for(let z of [-14,14]){g.cylinder(x,27,z,4,3.5,54,P.face,8);g.cylinder(x,57,z,3.5,0,14,P.metal,8);}
 }else if(t==='motor'){
   g.cylinder(0,7,0,23,23,14,P.metal,30);g.torus(0,13,0,23,2.5,P.light,40,7,.85);g.cylinder(0,19,0,14,14,12,P.face,24);g.torus(0,25,0,15,3,P.hot,40,9,.7);g.cylinder(0,29,0,5,5,12,P.metal,16);g.cylinder(0,38,0,5,0,10,P.edge,12);
   for(let i=0;i<8;i++){let a=i*TAU/8;g.push(0,0,0,a);g.box(0,13,20,5,8,7,P.face);g.box(0,18,18,.8,8,9,P.light,.5);g.pop();}
 }else if(t==='dock'){
   g.cylinder(0,5,0,26,26,9,P.face,32);g.torus(0,10,0,24,2.3,P.light,36,7,.85);g.torus(0,26,0,22,1.3,P.hot,40,6,.7);
   for(let a=0;a<4;a++){let t=a*TAU/4;g.push(0,0,0,t);g.box(0,15,20,6,30,6,P.metal);g.cylinder(0,35,20,3,0,20,P.face,10);g.box(0,24,20,1.3,17,1.3,P.light,.7);g.pop();}
   g.cylinder(0,12,0,10,9,10,P.glass,16);g.torus(0,19,0,8,1.2,P.hot,20,6,.9);
 }
 g.pop();return g;}
function ship(type='cruiser'){
 let g=new Geo(),P=PALETTES.onyx;let x=type==='freighter'?1.35:type==='scout'?.72:1;g.push(0,0,0,0,x,x,x);
 // Twin-winged onyx cruiser, wedge hull, segmented fuselage, lavender/red navigation lights.
 g.box(0,0,0,8,3,25,P.metal);g.box(0,1,1,5,3,15,P.face);g.cylinder(0,2,7,2.8,0.8,8,P.glass,10);g.cylinder(0,1,13,1.8,0,10,P.edge,8);
 for(let side of [-1,1]){
   g.tri([side*3,0,9],[side*23,-.2,-7],[side*6,0,-8],P.face);g.tri([side*3,-1,9],[side*6,-1,-8],[side*23,-1,-7],P.metal);
   g.beam([side*5,0,3],[side*21,0,-6],.75,P.hot,.6);g.box(side*5,0,-12,3,4,7,P.metal);g.box(side*5,0,-15,1.7,2,2,P.light,.86);
   g.tri([side*3,1,-9],[side*13,10,-12],[side*6,2,-17],P.face);g.tri([side*2,0,-10],[side*13,10,-12],[side*6,1,-16],P.metal);
   g.box(side*16,0,-6,2,.5,4,P.light,.7);
 }
 g.box(0,0,-17,3,2,5,P.hot,.85);g.box(0,-1,-14,2,1,2,P.light,.95);
 if(type==='freighter'){g.box(0,4,-1,9,6,8,P.face);g.box(0,7,-1,7,.4,8,P.light,.5);}
 if(type==='scout'){g.tri([-1,1,17],[1,1,17],[0,3,7],P.hot,.4);}
 g.pop();return g;}
function motorBase(){let g=new Geo(),P=PALETTES.gunmetal;g.cylinder(0,0,0,14,14,7,P.metal,24);g.cylinder(0,5.5,0,11,11,6,P.face,24);g.torus(0,9,0,12,1.2,P.edge,32,7);g.cylinder(0,10,0,6,6,10,P.metal,16);for(let i=0;i<8;i++){let a=i*TAU/8;g.push(0,0,0,a);g.box(0,2,12,5,3,6,P.face);g.pop();}return g;}
function motorRotor(){let g=new Geo(),P=PALETTES.onyx;g.cylinder(0,0,0,5,5,3,P.edge,20);g.torus(0,0,0,12,2,P.light,30,7,.8);for(let i=0;i<10;i++){let a=i*TAU/10;g.push(0,0,0,a);g.tri([-2,0,4],[3,1.5,5],[1,2.4,11],P.face);g.tri([-2,-.7,4],[1,1.8,11],[-3,1.5,10],P.edge);g.pop();}g.sphere(0,2,0,3,P.hot,14,7,.8);return g;}
function defaultModules(){return [
 {id:1,type:'gothic',name:'Obsidian Cathedral',x:-62,z:-43,rotation:.1,scale:1.14,palette:'onyx'},
 {id:2,type:'arrow',name:'Arrow Bastion',x:51,z:-59,rotation:.3,scale:1.0,palette:'gunmetal'},
 {id:3,type:'neon',name:'Skyline Spiral',x:85,z:18,rotation:-.2,scale:.96,palette:'titanium'},
 {id:4,type:'orbital',name:'Orbital Research Hub',x:-11,z:65,rotation:.3,scale:1,palette:'obsidian'},
 {id:5,type:'refinery',name:'Plasma Refinery',x:-83,z:54,rotation:.3,scale:.9,palette:'onyx'},
 {id:6,type:'bio',name:'Bio-Atrium',x:39,z:85,rotation:0,scale:.82,palette:'titanium'},
 {id:7,type:'fortress',name:'Storm Citadel',x:7,z:-95,rotation:0,scale:.88,palette:'obsidian'},
 {id:8,type:'motor',name:'Solar Flux Generator',x:94,z:-45,rotation:0,scale:.8,palette:'gunmetal'},
 {id:9,type:'dock',name:'Hyperspace Dock',x:-109,z:0,rotation:0,scale:.76,palette:'crimson'},
 {id:10,type:'gothic',name:'The Needle',x:-27,z:-102,rotation:.3,scale:.65,palette:'obsidian'},
 {id:11,type:'neon',name:'Aurora Observatory',x:3,z:116,rotation:.6,scale:.56,palette:'onyx'},
 {id:12,type:'arrow',name:'The Eastern Rise',x:112,z:58,rotation:0,scale:.55,palette:'crimson'}
 ];}

function appendGeo(target,source,mat=I()){
  for(let k=0;k<source.data.length;k+=10){let d=source.data;
    let p=pt(mat,[d[k],d[k+1],d[k+2]]),n=[mat[0]*d[k+3]+mat[4]*d[k+4]+mat[8]*d[k+5],mat[1]*d[k+3]+mat[5]*d[k+4]+mat[9]*d[k+5],mat[2]*d[k+3]+mat[6]*d[k+4]+mat[10]*d[k+5]];
    let len=Math.hypot(...n)||1;target.data.push(...p,n[0]/len,n[1]/len,n[2]/len,d[k+6],d[k+7],d[k+8],d[k+9]);
  }target.triangles+=source.triangles;return target;
}
function completeCity(modules=defaultModules(),fleet=12){
  let city=cityPlatform();for(let v of modules)appendGeo(city,building(v));
  let base=motorBase(),rotor=motorRotor();for(let i=0;i<12;i++){
    let a=i*TAU/12+TAU/24,x=Math.cos(a)*104,z=Math.sin(a)*104;
    appendGeo(city,base,tr(x,-42,z));appendGeo(city,rotor,tr(x,-33,z));
  }
  for(let i=0;i<fleet;i++){
    let f=i*2.399,r=162+(i%4)*23,x=Math.cos(f)*r,z=Math.sin(f)*r,y=41+(i%3)*19+Math.sin(i)*7;
    let yaw=Math.atan2(-Math.sin(f),Math.cos(f)),s=.65+(i%4)*.18;
    appendGeo(city,ship(['cruiser','scout','freighter'][i%3]),mult(tr(x,y,z),mult(ry(yaw),sc(s,s,s))));
  }return city;
}
/* ASTRAL SPECTRUM V2 — expanded 3.5D city geometry.
   Physical visual forms are artistic interpretations of the supplied photographs;
   atmospheric flight, levitation and plasma are speculative sci-fi concepts. */
const basePlatform=cityPlatform,baseBuilding=building,baseShip=ship,baseRotor=motorRotor;
PALETTES.onyx={metal:'#151b2a',face:'#2c374a',edge:'#8295af',light:'#a77bff',hot:'#ff345d',glass:'#294b76'};
PALETTES.gunmetal={metal:'#202531',face:'#414c5c',edge:'#aab9c7',light:'#54d6ff',hot:'#ff667e',glass:'#30516f'};
PALETTES.obsidian={metal:'#181521',face:'#2a273a',edge:'#8d839e',light:'#d9a8ff',hot:'#fd4565',glass:'#302a55'};
PALETTES.titanium={metal:'#343e50',face:'#526276',edge:'#d0dce6',light:'#71c9ff',hot:'#fa668e',glass:'#3e6282'};
PALETTES.crimson={metal:'#1c1927',face:'#423044',edge:'#a67991',light:'#da86ff',hot:'#ff375a',glass:'#4b2e54'};
function spire(g,x,z,bottom,height,r,p){
 g.cylinder(x,bottom+height*.26,z,r*.9,r*.6,height*.5,p.face,8);
 g.cylinder(x,bottom+height*.61,z,r*.68,r*.32,height*.29,p.edge,8);
 g.cylinder(x,bottom+height*.85,z,r*.34,0,height*.25,p.metal,8);
 g.beam([x,bottom+height*.92,z],[x,bottom+height+5,z],.13,p.light,.55);
}
function arch(g,x,y,z,w,h,col,light){
 const n=9;for(let i=0;i<n;i++){let a=Math.PI*i/(n-1),b=Math.PI*(i+1)/(n-1),a0=[x+w*.5*Math.cos(a),y+h*.67+h*.33*Math.sin(a),z],a1=[x+w*.5*Math.cos(b),y+h*.67+h*.33*Math.sin(b),z];g.beam(a0,a1,.46,col);}
 g.beam([x-w/2,y,z],[x-w/2,y+h*.67,z],.42,col);g.beam([x+w/2,y,z],[x+w/2,y+h*.67,z],.42,col);
 if(light)g.box(x,y+h*.33,z,.24,h*.62,.18,light,.75);
}
function structureBase(g,r,P){g.cylinder(0,3,0,r,r,6,P.metal,24);g.torus(0,6,0,r-1.4,.65,P.edge,32,5,.24);g.torus(0,6.4,0,r-3,.36,P.light,32,5,.6);}
function cityPlatformV2(){
 let g=basePlatform(),P=PALETTES.onyx,Q=PALETTES.gunmetal;
 // Suspended tiered ring city: dark graphite engineering, vertical nacelles, magenta skyrail.
 for(let i=0;i<3;i++){let y=23+i*14,r=[125,108,88][i];g.torus(0,y,0,r,1.6,i===1?P.hot:P.light,96,7,.74);for(let k=0;k<18;k++){let a=k*TAU/18,x=Math.cos(a)*r,z=Math.sin(a)*r;g.beam([x,11,z],[x,y,z],.5,P.edge,.18);}}
 for(let i=0;i<24;i++){let a=i*TAU/24,r=145,x=Math.cos(a)*r,z=Math.sin(a)*r;g.cylinder(x,22,z,1.15,0,16,Q.face,8);g.sphere(x,30,z,1.25,i%3===0?P.hot:P.light,8,5,.95);}
 // Curved aerial highway segments form a radial Gothic bridge rhythm.
 for(let j=0;j<4;j++){let a=j*TAU/4+Math.PI/4;g.push(0,0,0,a);for(let z=15;z<120;z+=11){g.box(0,17,z,14,1.9,9,P.face);g.box(-6.8,18.5,z,1.1,1.1,10,P.edge);g.box(6.8,18.5,z,1.1,1.1,10,P.edge);g.box(0,18.5,z,1,.15,8,P.light,.4);}for(let z=20;z<118;z+=22){arch(g,0,-3,z,16,19,P.edge,P.hot);}g.pop();}
 // Lower city engine chassis with tapered armor and glowing field rings.
 for(let i=0;i<8;i++){let a=i*TAU/8,x=Math.cos(a)*71,z=Math.sin(a)*71;g.cylinder(x,-38,z,12,8,25,P.face,16);g.torus(x,-45,z,12,2,P.light,22,7,.83);g.cylinder(x,-58,z,6,0,14,P.metal,14);g.beam([x*.48,-30,z*.48],[x,-35,z],2,P.edge);}
 for(let i=0;i<7;i++)g.torus(0,-60-i*3,0,26+i*1.7,.58,i%2?P.hot:P.light,64,6,.7);
 // Central communications citadel: ribbed plasma tower, orbital docking collars and antennae.
 g.cylinder(0,29,0,16,14,30,P.face,24);g.cylinder(0,53,0,12,9,25,P.metal,24);
 for(let i=0;i<8;i++){let a=i*TAU/8;g.beam([16*Math.cos(a),19,16*Math.sin(a)],[9*Math.cos(a),87,9*Math.sin(a)],1.5,P.edge);g.cylinder(10*Math.cos(a),65,10*Math.sin(a),1.4,0,27,P.metal,7);}
 g.torus(0,51,0,27,2.7,P.face,56,8);g.torus(0,51.5,0,28.3,.7,P.light,56,6,.94);
 g.torus(0,75,0,20,2.1,P.face,52,8);g.torus(0,76,0,20,.6,P.hot,52,6,.8);
 spire(g,0,0,79,57,7,P);
 // Modular passenger flight rings at different altitudes.
 for(let t=0;t<2;t++){let y=40+t*27,r=174+t*20;g.torus(0,y,0,r,.8,t?P.light:Q.edge,96,6,.61);
 for(let k=0;k<8;k++){let a=k*TAU/8;let cx=Math.cos(a)*r,cz=Math.sin(a)*r;g.cylinder(cx,y,cz,4,4,1,P.metal,12);g.torus(cx,y+.8,cz,5.2,.45,t?P.hot:P.light,16,5,.8);}}
 // Lift portals and modular landing bridges outward.
 for(let i=0;i<6;i++){let a=i*TAU/6;g.push(0,0,0,a);g.box(0,13,178,8,3,42,P.face);g.box(-4.6,15,178,.55,.9,40,P.light,.5);g.box(4.6,15,178,.55,.9,40,P.light,.5);g.torus(0,17,193,18,1.25,P.hot,40,6,.82);g.pop();}
 return g;
}
function buildingV2(spec){
 let P=PALETTES[spec.palette]||PALETTES.onyx,t=spec.type,g;
 if(['spa','sculpture','skybridge'].includes(t)){g=new Geo();g.push(spec.x,11,spec.z,spec.rotation||0,spec.scale||1,(spec.scale||1)*(spec.height||1),spec.scale||1);
 if(t==='spa'){
  structureBase(g,29,P);g.cylinder(0,8,0,26,23,6,P.face,44);g.cylinder(0,11.4,0,23.5,23.5,.6,P.glass,50);g.torus(0,12.1,0,23,1.8,P.edge,54,8);g.torus(0,12.4,0,20.3,.44,P.light,50,7,.73);
  for(let i=0;i<3;i++){let a=Math.PI+(i-1)*.33;g.cylinder(Math.cos(a)*23,19,Math.sin(a)*23,3,4,13,P.metal,10);g.sphere(Math.cos(a)*23,26,Math.sin(a)*23,4,P.face,14,7);}
  for(let i=0;i<8;i++){let a=i*TAU/8;g.sphere(19*Math.cos(a),11.9,19*Math.sin(a),1.2,'#93f1ee',8,5,.88);}
  g.box(0,2,27,17,6,7,P.metal);g.box(0,5.5,27,15,.5,7,P.edge);
 }else if(t==='sculpture'){
  structureBase(g,25,P);g.cylinder(0,8,0,16,12,6,P.face,28);g.sphere(0,20,0,9,P.edge,24,12);g.torus(0,26,0,15,5,P.face,32,10);g.torus(0,29,0,16,1.1,P.light,32,6,.66);
  for(let i=0;i<7;i++){let a=i*TAU/7;g.beam([0,30,0],[15*Math.cos(a),40+7*Math.sin(a*2),15*Math.sin(a)],3.5,P.face);g.sphere(15*Math.cos(a),40+7*Math.sin(a*2),15*Math.sin(a),3,P.edge,12,7);}
  for(let i=0;i<8;i++){let a=i*TAU/8;g.box(21*Math.cos(a),5,21*Math.sin(a),2,8,2,i%2?P.hot:P.light,.75);}
 }else if(t==='skybridge'){
  structureBase(g,27,P);g.cylinder(0,33,0,10,7,65,P.face,16);
  for(let i=0;i<4;i++){let y=21+i*17;g.box(0,y,0,44,12,29,P.glass);g.box(0,y+6,0,48,1.5,33,P.face);g.box(0,y-6,0,46,.9,30,P.face);g.box(0,y+6.6,0,47,.35,32,P.light,.76);for(let z of [-15,15])for(let k=0;k<8;k++)g.box(-18+k*5.2,y,z,2.2,7,.3,P.edge,.13);}
  g.cylinder(0,82,0,8,3,17,P.face,12);spire(g,0,0,87,28,3,P);
 }
 g.pop();return g;
 }
 g=baseBuilding(spec);
 g.push(spec.x,11,spec.z,spec.rotation||0,spec.scale||1,(spec.scale||1)*(spec.height||1),spec.scale||1);
 if(t==='gothic'){
  for(let side of [-1,1])for(let z of [-8,8]){
   spire(g,side*13,z,32,42,3.7,P);g.beam([side*17,8,z],[side*12,48,z],1.4,P.edge);g.beam([side*17,8,z],[side*11,28,z+Math.sign(z)*8],.8,P.edge);
  }
  for(let k=0;k<4;k++)for(let side of [-1,1]){let y=5+k*9;arch(g,side*6,y,10.1,5,7,P.edge,P.light);arch(g,side*6,y,-10.1,5,7,P.edge,P.light);}
  for(let j=0;j<8;j++){let a=j*TAU/8;g.beam([6*Math.cos(a),66,6*Math.sin(a)],[3*Math.cos(a),91,3*Math.sin(a)],.9,P.edge);}g.torus(0,66,0,6.6,1.3,P.hot,24,6,.55);
  for(let x of [-7,0,7])g.box(x,11,10.3,1.4,16,.3,P.light,.5);
 }else if(t==='arrow'){
  for(let i=0;i<8;i++){let a=i*TAU/8;g.push(0,0,0,a);g.beam([0,2,17],[0,48,11],1.4,P.edge);g.box(0,39,12,2.4,19,.8,P.light,.68);g.pop();}
  for(let i=0;i<4;i++){let a=i*TAU/4;g.push(0,0,0,a);arch(g,0,5,14,8,18,P.edge,P.hot);g.pop();}g.torus(0,61,0,11.3,1,P.light,40,6,.65);
 }else if(t==='neon'){
  for(let i=0;i<4;i++){let y=14+i*16;g.torus(0,y,0,20,1.1,P.light,40,6,.73);for(let k=0;k<14;k++){let a=k*TAU/14;let x=12*Math.cos(a),z=12*Math.sin(a);g.box(x,y,z,1.1,7,1.1,P.glass);}}
  for(let i=0;i<4;i++){let a=i*TAU/4;g.push(0,0,0,a);g.box(0,31,16,.6,55,.7,P.hot,.65);g.pop();}
  g.torus(0,87,0,11,1.1,P.light,36,6,.82);
 }else if(t==='orbital'){
  for(let i=0;i<12;i++){let a=i*TAU/12;let x=Math.cos(a)*22,z=Math.sin(a)*22;g.box(x,12,z,2.9,12,2.9,P.glass);g.beam([x,15,z],[x*.55,39,z*.55],.6,P.edge);}
  for(let j=0;j<3;j++)g.torus(0,36+j*9,0,12+j*.7,.7,j%2?P.hot:P.light,40,6,.7);
 }else if(t==='refinery'){
  for(let i=0;i<12;i++){let a=i*TAU/12;g.push(0,0,0,a);g.box(0,12,21,2.7,22,3.8,P.face);g.box(0,24,20,2,3,4,P.light,.53);g.pop();}
  for(let j=0;j<4;j++){g.torus(0,22+j*7,0,17-j,1.2,j%2?P.hot:P.light,40,7,.76);}g.sphere(0,29,0,4,P.hot,18,10,.96);
  g.beam([0,44,0],[0,65,0],1.4,P.edge);g.sphere(0,65,0,2.5,P.light,12,6,.9);
 }else if(t==='bio'){
  for(let i=0;i<10;i++){let a=i*TAU/10;let x0=Math.cos(a)*20,z0=Math.sin(a)*20;g.beam([x0,14,z0],[x0*.7,43,z0*.7],1,P.edge);g.sphere(x0,15,z0,1.3,P.light,10,6,.65);}
 }else if(t==='fortress'){
  for(let i=0;i<4;i++){let a=i*TAU/4;g.push(0,0,0,a);for(let n=0;n<6;n++){arch(g,-12+n*5,8,17,3.2,15,P.edge,P.light);}g.box(0,33,18,27,.6,.8,P.hot,.62);g.pop();}for(let x of [-11,11])for(let z of [-11,11])spire(g,x,z,45,44,4,P);
 }else if(t==='motor'){
  for(let i=0;i<12;i++){let a=i*TAU/12;g.push(0,0,0,a);g.box(0,17,22,2.5,8,3,P.face);g.box(0,18,24,.75,7,1,P.hot,.57);g.pop();}
  for(let j=0;j<3;j++)g.torus(0,20+j*8,0,14-j*3,1.2,j%2?P.light:P.hot,36,7,.87);
 }else if(t==='dock'){
  for(let i=0;i<8;i++){let a=i*TAU/8;g.push(0,0,0,a);g.box(0,9,34,11,1.5,21,P.face);g.box(-5,10,34,.45,.7,20,P.light,.74);g.box(5,10,34,.45,.7,20,P.light,.74);g.cylinder(0,9.5,44,6,6,1,P.face,16);g.pop();}
  for(let i=0;i<3;i++)g.torus(0,40+i*5,0,14+i*3,.6,i%2?P.light:P.hot,36,6,.73);
 }
 // Material seam lines and visible power bus (modular architecture is swap-friendly).
 if(!['dock','bio'].includes(t)){
  g.torus(0,6.8,0,22,.45,P.hot,36,5,.49);
  for(let k=0;k<8;k++){let a=k*TAU/8;g.sphere(Math.cos(a)*20,7,Math.sin(a)*20,.65,P.light,8,5,.72);}
 }
 g.pop();return g;
}
function shipV2(type='cruiser'){
 let g=baseShip(type),P=PALETTES.onyx,f=type==='freighter'?1.35:type==='scout'?.72:1;
 g.push(0,0,0,0,f,f,f);
 for(let k=0;k<4;k++){let z=-8+k*5;g.box(0,1.4,z,4,.2,1,P.edge);g.box(0,2,z,3,.2,.65,P.light,.4);}
 for(let s of [-1,1]){
  for(let k=0;k<5;k++){let z=-13+k*3;g.box(s*5.1,.7,z,1.1,.5,1.4,k%2?P.face:P.edge);}
  g.cylinder(s*6,0,-16,3,3,5,P.metal,12);g.torus(s*6,0,-17.8,2.4,.6,P.hot,16,7,.82);
  g.beam([s*7,1,5],[s*20,.2,-6],.36,P.light,.65);g.beam([s*6,-1,-9],[s*17,-.5,-8],.43,P.edge);
  g.sphere(s*18,.1,-6,1,P.hot,10,6,.82);
 }
 g.torus(0,1,12,2.7,.44,P.light,16,6,.74);
 for(let i=0;i<2;i++){g.box(0,-1,-11+i*3,6,.4,1.8,P.face);}
 g.pop();return g;
}
function motorRotorV2(){let g=baseRotor(),P=PALETTES.onyx;for(let i=0;i<12;i++){let a=i*TAU/12;g.push(0,0,0,a);g.box(0,0,11,2,2.5,3,P.face);g.box(0,1.7,11,.7,.3,2.2,P.hot,.82);g.pop();}g.torus(0,3,0,9,1.1,P.hot,32,7,.75);return g;}
function defaultModulesV2(){let d=defaultModules().map(x=>({...x}));let extra=[
 ['gothic','Raven Spire',-112,-70,.62,'obsidian'],
 ['gothic','Cathedral of Cinders',-8,-122,.64,'gunmetal'],
 ['neon','Astral Flux Skyscraper',110,101,.57,'titanium'],
 ['fortress','Obsidian Keep',-117,95,.55,'onyx'],
 ['skybridge','Skybridge Tower',69,119,.65,'titanium'],
 ['sculpture','Sculptural Plaza',-50,117,.64,'gunmetal'],
 ['spa','Floating Hydro Atrium',114,-7,.67,'crimson'],
 ['refinery','Refinery Annex',-123,-12,.53,'gunmetal'],
 ['dock','Eastern Cargo Dock',49,-125,.52,'obsidian'],
 ['arrow','Arrow Monument',-94,-105,.49,'gunmetal'],
 ['neon','Tri-Spiral Observatory',-28,117,.47,'onyx'],
 ['gothic','Dusk Citadel',68,-103,.45,'onyx'],
 ['skybridge','North Sky Deck',17,108,.46,'crimson'],
 ];for(let [t,n,x,z,s,p] of extra){d.push({id:d.length+1,type:t,name:n,x,z,rotation:(d.length%6)*.16,scale:s,height:1,palette:p});}return d;}
function completeCityV2(modules=defaultModulesV2(),fleet=14){let result=cityPlatformV2();for(let v of modules)appendGeo(result,buildingV2(v));let base=motorBase(),rotor=motorRotorV2();for(let i=0;i<12;i++){let a=i*TAU/12+TAU/24,x=Math.cos(a)*104,z=Math.sin(a)*104;appendGeo(result,base,tr(x,-42,z));appendGeo(result,rotor,tr(x,-33,z));}for(let i=0;i<fleet;i++){let f=i*2.399,r=171+(i%4)*23,x=Math.cos(f)*r,z=Math.sin(f)*r,y=45+(i%3)*19+Math.sin(i)*7,s=.65+(i%4)*.18;appendGeo(result,shipV2(['cruiser','scout','freighter'][i%3]),mult(tr(x,y,z),mult(ry(-f),sc(s,s,s))));}return result;}

const API={appendGeo,completeCity:completeCityV2,Geo,PALETTES,cityPlatform:cityPlatformV2,building:buildingV2,ship:shipV2,motorBase,motorRotor:motorRotorV2,defaultModules:defaultModulesV2,I,mult,tr,sc,ry,rx,DEG,TAU,pt};
if(typeof module!=='undefined'&&module.exports)module.exports=API;
root.AstralGeo=API;
})(typeof window!=='undefined'?window:globalThis);
