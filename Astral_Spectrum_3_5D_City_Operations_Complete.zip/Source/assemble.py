from pathlib import Path
import re,base64
root=Path(__file__).resolve().parent
t=(root/'APP_TEMPLATE.html').read_text()
G=(root/'geometry-core.js').read_text()
O=(root/'operations.js').read_text()
F=(root/'operations_ui.html').read_text()
R=(root/'operations_right.html').read_text()
css='''
/* CITY OPERATIONS — glass consoles, readable repair queue, and encoding buffers */
.panels{width:302px}.panels.left{left:14px}.panels.right{right:14px}
.sys-textarea,.sys-input{display:block;width:100%;border:1px solid #48637c;background:#070f1c;color:#d6edff;border-radius:5px;padding:9px 9px;resize:vertical;font:11px/1.48 ui-monospace,SFMono-Regular,Consolas,monospace;overflow:auto;min-height:54px}
.sys-textarea:focus,.sys-input:focus{outline:2px solid #ad8bff}
.sys-input{min-height:auto}.system-card{border-top:2px solid #7265ae;scroll-margin-top:5px}
.system-status{display:flex;align-items:center;gap:7px;border:1px solid #37506b;background:#101e2e;padding:8px;border-radius:5px;margin-bottom:10px;min-width:0}
.system-status b{color:#b3dfff;font:700 10px ui-monospace,monospace;min-width:0;flex:1}.system-status small{font:8px ui-monospace,monospace;color:#b5a2d9}
.live-led{width:7px;height:7px;min-width:7px;border-radius:50%;background:#6de6bd;box-shadow:0 0 8px #6de6bd}.live-led.off{background:#fa677b;box-shadow:0 0 6px #ed4169}.live-led.connected{background:#6cecff;box-shadow:0 0 12px #53e9ff}
.meter-caption{display:flex;justify-content:space-between;align-items:center;padding:5px 0;font-size:10px;color:#a3b6c8;letter-spacing:.04em}.meter-caption b{color:#dbeaff;font:12px ui-monospace,monospace}
.details{margin-top:10px;border-top:1px solid #32516b;padding-top:9px}.details summary{cursor:pointer;color:#a1d8fd;font:700 10px ui-monospace,monospace;letter-spacing:.07em}
.eventlog{background:#060b15;border:1px solid #283e54;border-radius:4px;margin:9px 0;padding:7px;max-height:103px;overflow-y:auto;color:#9eb4c9;font:9px/1.7 ui-monospace,monospace;overflow-wrap:anywhere}.eventlog:empty{display:none}
.workorders-top{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}.workorders-top>div{border:1px solid #3c5270;background:#111e31;border-radius:5px;padding:8px 6px;text-align:center}
.workorders-top small{font:8px monospace;color:#849fb8;display:block;letter-spacing:.07em}.workorders-top strong{font:bold 19px monospace;color:#d6c2ff}
.repair-list{max-height:263px;overflow-y:auto;margin:9px 0 8px;padding-right:3px;scrollbar-width:thin;scrollbar-color:#48647b transparent}
.order-row{display:flex;width:100%;align-items:center;justify-content:space-between;text-align:left;margin-bottom:5px;gap:7px;padding:9px 6px;font-size:10px;background:#0c192b;border:1px solid #345371}
.order-row span{flex:1;min-width:0;line-height:1.4}.order-row.selected{background:#302343;border-color:#c28afe;box-shadow:inset 3px 0 #bd86ff}.order-badge{font:bold 8px monospace;white-space:nowrap;border:1px solid;border-radius:3px;padding:3px 4px}
.order-badge.queued{color:#c2cce3;border-color:#61728c}.order-badge.diagnosing{color:#b6daff;border-color:#499dc4}.order-badge.repairing{color:#ffe0a0;border-color:#b18d43}.order-badge.complete{color:#8ef9c9;border-color:#42ad85}.order-badge.cancelled{color:#c79ca8;border-color:#715866}
.order-detail{border-left:2px solid #a976f3;background:#1b2636;padding:8px;color:#b7cfe5;font:10px/1.65 ui-monospace,monospace;min-height:36px;margin-bottom:8px}
button:disabled{opacity:.43;cursor:not-allowed}#footer .cluster button.quick{border-color:#805bb2;color:#e6ceff}
@media(max-width:1100px){.panels{width:257px}}
@media(max-width:760px){.panels{width:49%}.order-row{flex-direction:column;align-items:flex-start}.workorders-top strong{font-size:15px}.system-status small{display:none}}
'''
css+='''
#conceptOverlay{position:absolute;inset:0;z-index:1;background:#040715;display:none;align-items:center;justify-content:center;pointer-events:none}
#conceptOverlay.visible{display:flex}#conceptOverlay img{width:100%;height:100%;object-fit:contain;filter:saturate(1.13) contrast(1.06)}
#conceptOverlay .caption-panel{position:absolute;bottom:93px;left:50%;transform:translateX(-50%);font:700 11px monospace;letter-spacing:.1em;color:#d8c4ff;text-shadow:0 2px 9px #000;padding:7px 12px;border:1px solid #686a95;background:#090e1cbf;text-align:center;white-space:nowrap}
'''
t=t.replace('</style></head>','\n'+css+'</style></head>',1)
poster=root/'Astral_City_3_5D_Preview.jpg'
if not poster.exists(): poster=root.parent/'Astral_Spectrum_City_3_5D_Preview.jpg'
preview=base64.b64encode(poster.read_bytes()).decode('ascii')
t=t.replace('<div id="reticle"></div></div>', '<div id="reticle"></div><div id="conceptOverlay"><img id="conceptImg" alt="Cinematic perspective of the levitating Gothic space city" src="data:image/jpeg;base64,'+preview+'"><span class="caption-panel" id="conceptLabel">3.5D CONCEPT VIEW · 3D CITY CONTINUES BEHIND</span></div></div>',1)

# Renumber existing panels, insert flux before radar
t=t.replace('<div class="card"><h2>03 / SPACEPORT RADAR',F+'\n<div class="card"><h2>04 / SPACEPORT RADAR',1)
t=t.replace('<div class="card"><h2>04 / CONTROLS','<div class="card"><h2>05 / CONTROLS',1)
t=t.replace('<div class="card"><h2>05 / MODULE ARCHITECT','<div class="card"><h2>06 / MODULE ARCHITECT',1)
t=t.replace('<div class="card"><h2>06 / DESIGN + EXPORT','<div class="card"><h2>07 / DESIGN + EXPORT',1)
t=t.replace('<option value="dock">Docking portal / module</option>', '<option value="dock">Docking portal / module</option><option value="skybridge">Skybridge / transit tower</option><option value="sculpture">Sculptural plaza / monument</option><option value="spa">Floating hydro atrium / spa</option>',1)
# check exact term in html in case no match; replace using before close of buildingType select
if '<option value="skybridge">' not in t:
 t=t.replace('<option value="dock">Modular docking ring</option>', '<option value="dock">Modular docking ring</option><option value="skybridge">Skybridge / transit tower</option><option value="sculpture">Sculptural plaza / monument</option><option value="spa">Floating hydro atrium / spa</option>',1)
# insert ops after exports at end of right panel
t=t.replace('</div>\n</div>\n<div id="toast" role="status"></div>', '</div>\n'+R+'\n</div>\n<div id="toast" role="status"></div>',1)
t=t.replace('>CITY OVERVIEW</button>', '>CITY OVERVIEW</button><button class="quick" id="conceptBtn">CONCEPT VIEW</button><button class="quick" id="navFlux">FLUX LAB</button><button class="quick" id="navNet">NETWORK I/O</button><button class="quick" id="navRepairs">REPAIR OPS</button>',1)
t=t.replace('BUILT WITH PROCEDURAL WEBGL · NO LOGIN · NO INTERNET REQUIRED','PROCEDURAL 3.5D WEBGL · OFFLINE READY · OPTIONAL WEBSOCKET LINK',1)
t=t.replace('Architectural modules</span><strong id="buildingTotal">12</strong>', 'Architectural modules</span><strong id="buildingTotal">25</strong>',1)
t=t.replace('Preparing architectural sectors, spacecraft trajectories and model geometry...', 'Building the Gothic skyline, ring transit, dock terminals, autonomous craft, repair drones and neural consoles...',1)
t=t.replace('OFFLINE 3D ARCHITECT · PROTOTYPE 01','3.5D CITY ARCHITECT · OPERATIONAL SYSTEMS v2.1',1)
t=t.replace('<p>The browser animates ships and rotor equipment; STL is a static format and cannot store movement or interaction.', '<p>Open FLUX LAB for simulated motor power and magnetic direction. Open NETWORK I/O for Base64/Hex/Binary/URI/JSON conversion or an opt-in WebSocket link. REPAIR OPS tracks equipment work orders across electronics, spacecraft, transit, and buildings.</p><p>The browser animates ships and rotor equipment; STL is a static format and cannot store movement or interaction.',1)
# If the user lacks WebGL, show a concept preview while keeping the editor, network and repair consoles usable.
old="const G=window.AstralGeo,C=document.getElementById('gl'),gl=C.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});const $=id=>document.getElementById(id);"
new="""const G=window.AstralGeo,C=document.getElementById('gl');const $=id=>document.getElementById(id);
let gl=C.getContext('webgl',{alpha:true,antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
const previewOnly=!gl;
if(previewOnly){let fake=new Proxy({VERTEX_SHADER:35633,FRAGMENT_SHADER:35632,COMPILE_STATUS:35713,LINK_STATUS:35714,ARRAY_BUFFER:34962,STATIC_DRAW:35044,FLOAT:5126,TRIANGLES:4,COLOR_BUFFER_BIT:16384,DEPTH_BUFFER_BIT:256,DEPTH_TEST:2929,LEQUAL:515,CULL_FACE:2884,createShader:()=>({}),createProgram:()=>({}),createBuffer:()=>({}),getShaderParameter:()=>true,getProgramParameter:()=>true,getUniformLocation:()=>({}),getAttribLocation:()=>1},{get:(t,k)=>t[k]??(()=>{})});gl=fake;$('conceptOverlay').classList.add('visible');$('conceptLabel').textContent='CONCEPT PREVIEW · ENABLE WEBGL TO VIEW LIVE 3D GEOMETRY';}
"""
assert old in t
t=t.replace(old,new,1)
t=t.replace("if(!gl){$('loading').innerHTML='<div class=\"center\"><h2>WebGL unavailable</h2><p>This local browser needs WebGL enabled (hardware acceleration). Try an updated Chrome, Firefox, or Safari browser.</p></div>';return;}",'',1)

t=t.replace('/*__GEO_CORE__*/',G,1)
t=t.replace('nextId=13, selectedId=1','nextId=G.defaultModules().length+1, selectedId=1',1)
t=t.replace('nextId=13;selectedId=1;','nextId=modules.length+1;selectedId=1;',1)
t=t.replace("dock:'Modular Space Dock'}", "dock:'Modular Space Dock',skybridge:'Transit Skybridge',sculpture:'Sculptural Plaza',spa:'Floating Hydro Atrium'}",1)
t=t.replace("'fortress','motor','dock'];modules=", "'fortress','motor','dock','skybridge','sculpture','spa'];modules=",1)
t=t.replace("updateBuildings();notify('CITY DESIGN LOADED", "updateBuildings();if(d.operations)importOps(d.operations);notify('CITY DESIGN LOADED",1)
t=t.replace("version:1,units:'conceptual metres',modules,options", "version:2,units:'conceptual metres',modules,operations:{flux:{...flux},repairOrders:repairOrders.map(o=>({...o}))},options",1)
t=t.replace('refreshList();$(\'buildingTotal\').textContent=modules.length;', "refreshList();$('buildingTotal').textContent=modules.length;if(window.__opsReady)updateRepairTargets();",1)
t=t.replace('elapsed*(motorActive&&!paused?1.8:0)+i','elapsed*(motorActive&&!paused?1.8*fluxSpeed():0)+i',1)
# insert 3D repair aircraft right after vessel loop, before render end
s='shipPositions.push([x,y,z]);}\n}'
assert s in t,'ship position seam missing'
t=t.replace(s,'shipPositions.push([x,y,z]);}\n drawMaintenanceVehicles();\n}',1)
# update map radar for work orders while ctx scale applied
s="ctx.fillStyle='#ff5c7a';ctx.beginPath();ctx.arc(camera.p[0],camera.p[2],6,0,Math.PI*2);ctx.fill();ctx.restore();"
assert s in t
p=s.replace('ctx.restore();','drawRepairRadar(ctx);ctx.restore();')
t=t.replace(s,p,1)
# Tick before render; dt may zero on init
s='updateCamera(dt);render();mapAccum+=dt;'
assert s in t
t=t.replace(s,'updateCamera(dt);tickOperations(dt);render();mapAccum+=dt;',1)
# Toggle reference/concept view and preserve screenshot exports even on browsers without a WebGL context.
old="$('screenshot').onclick=()=>{render();C.toBlob(b=>b&&downloadBlob('Astral_Spectrum_City.png',b,'image/png'),'image/png');notify('3D VIEW CAPTURED');};"
new="""$('conceptBtn').onclick=()=>{let el=$('conceptOverlay');if(previewOnly){notify('WEBGL IS OFF · VIEWING 3.5D CONCEPT PREVIEW');return;}el.classList.toggle('visible');$('conceptBtn').textContent=el.classList.contains('visible')?'BACK TO 3D':'CONCEPT VIEW';};
$('screenshot').onclick=()=>{if(previewOnly||$('conceptOverlay').classList.contains('visible')){let cv=document.createElement('canvas'),im=$('conceptImg');cv.width=im.naturalWidth;cv.height=im.naturalHeight;cv.getContext('2d').drawImage(im,0,0);cv.toBlob(b=>b&&downloadBlob('Astral_Spectrum_City_Concept.png',b,'image/png'),'image/png');notify('CONCEPT IMAGE CAPTURED');}else{render();C.toBlob(b=>b&&downloadBlob('Astral_Spectrum_City.png',b,'image/png'),'image/png');notify('LIVE CITY VIEW CAPTURED');}};"""
assert old in t
t=t.replace(old,new,1)

# Insert operations after source line but before initialization at bottom
s="visited.add(0);updateRoute();bindInspector();"
assert s in t
t=t.replace(s,O+'\n'+s,1)
# Improve added instruction note existing buttons input
assert 'function fluxSpeed()' in t
assert 'Repair order monitor' in t or 'REPAIR ORDER MONITOR' in t
out=root.parent/'Astral_Spectrum_3_5D_City_Operations.html'
out.write_text(t)
print(out, 'bytes',out.stat().st_size,'modules', t.count('options'), 'ops',len(O))
